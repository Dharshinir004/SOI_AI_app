import { Entity, PrimaryGeneratedColumn, Column, CreateDateColumn, ManyToOne } from 'typeorm';
import { User } from './User';

@Entity()
export class Job {
  @PrimaryGeneratedColumn()
  id!: number;

  @Column()
  title!: string;

  @Column({ type: 'text' })
  description!: string;

  @ManyToOne(() => User)
  org!: User;

  @Column({ type: 'varchar' })
  type!: string;
  // 'job', 'internship', 'training'

  @Column({ default: 'open' })
  status!: string;

  @CreateDateColumn()
  createdAt!: Date;
}
