import express from 'express';
import { getRepository } from 'typeorm';
import { Team } from '../entities/Team';
import { User } from '../entities/User';
import { requireAuth, AuthRequest } from '../middleware/auth';

const router = express.Router();

// Get all teams
router.get('/', requireAuth, async (_req, res) => {
  const teams = await getRepository(Team).find({ relations: ['members', 'createdBy'] });
  res.json(teams);
});

// Create new team
router.post('/', requireAuth, async (req: AuthRequest, res) => {
  const repo = getRepository(Team);
  const userRepo = getRepository(User);
  const user = await userRepo.findOne(req.userId);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const team = repo.create({ ...req.body, createdBy: user, members: [user] });
  await repo.save(team);
  res.json(team);
});

// Join team
router.post('/:id/join', requireAuth, async (req: AuthRequest, res) => {
  const teamRepo = getRepository(Team);
  const userRepo = getRepository(User);
  const team = await teamRepo.findOne(req.params.id, { relations: ['members'] });
  const user = await userRepo.findOne(req.userId);
  if (!team || !user) return res.status(404).json({ error: 'Not found' });
  if (team.members.some((m) => m.id === user.id)) return res.status(409).json({ error: 'Already joined' });
  team.members.push(user);
  await teamRepo.save(team);
  res.json(team);
});

export default router;
