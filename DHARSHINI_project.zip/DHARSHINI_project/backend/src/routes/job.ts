import express from 'express';
import { getRepository } from 'typeorm';
import { Job } from '../entities/Job';
import { User } from '../entities/User';
import { requireAuth, AuthRequest } from '../middleware/auth';

const router = express.Router();

// Get all jobs
router.get('/', requireAuth, async (_req, res) => {
  const jobs = await getRepository(Job).find({ relations: ['org'] });
  res.json(jobs);
});

// Create job (recruiter/expert)
router.post('/', requireAuth, async (req: AuthRequest, res) => {
  const userRepo = getRepository(User);
  const jobRepo = getRepository(Job);
  const user = await userRepo.findOne(req.userId);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const job = jobRepo.create({ ...req.body, org: user });
  await jobRepo.save(job);
  res.json(job);
});

// Apply to job (stub response, you will link to Application entity later)
router.post('/:id/apply', requireAuth, async (req: AuthRequest, res) => {
  res.json({ success: true, message: 'Application received (not yet implemented)' });
});

export default router;
