import express from 'express';
import { getRepository } from 'typeorm';
import { Profile } from '../entities/Profile';
import { requireAuth, AuthRequest } from '../middleware/auth';
import { User } from '../entities/User';

const router = express.Router();

router.get('/', requireAuth, async (req: AuthRequest, res) => {
  const repo = getRepository(Profile);
  const profile = await repo.findOne({ where: { user: { id: req.userId } }, relations: ['user'] });
  res.json(profile);
});

router.post('/', requireAuth, async (req: AuthRequest, res) => {
  const repo = getRepository(Profile);
  const userRepo = getRepository(User);
  let profile = await repo.findOne({ where: { user: { id: req.userId } } });
  if (!profile) {
    const user = await userRepo.findOne(req.userId);
    profile = repo.create({ user, ...req.body });
  } else {
    repo.merge(profile, req.body);
  }
  await repo.save(profile);
  res.json(profile);
});

export default router;
