import express from 'express';
import cors from 'cors';
import http from 'http';
import { Server as SocketIOServer } from 'socket.io';
import dotenv from 'dotenv';
import { createConnection } from 'typeorm';
import { User } from './entities/User';
import { Profile } from './entities/Profile';
import { Team } from './entities/Team';
import { Job } from './entities/Job';
import authRoutes from './routes/auth';
import profileRoutes from './routes/profile';
import teamRoutes from './routes/team';
import jobRoutes from './routes/job';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new SocketIOServer(server, {
  cors: { origin: '*' },
});

// Health check
app.get('/', (_req, res) => {
  res.json({ status: 'OK', message: 'Backend API running' });
});

// Register routes
app.use('/auth', authRoutes);
app.use('/profile', profileRoutes);
app.use('/teams', teamRoutes);
app.use('/jobs', jobRoutes);

// Socket.io real-time chat
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);
  socket.on('chat message', (msg) => {
    io.emit('chat message', msg);
  });
  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

// Start after DB connection
async function start() {
  await createConnection({
    type: 'postgres',
    url: process.env.DATABASE_URL,
    entities: [User, Profile, Team, Job],
    synchronize: true,
    logging: true,
  });
  const PORT = process.env.PORT || 5000;
  server.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

start().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
