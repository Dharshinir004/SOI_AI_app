import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, Button, FlatList, StyleSheet } from 'react-native';
import io from 'socket.io-client';

const socket = io('http://localhost:5000');

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [chatInput, setChatInput] = useState('');
  const [messages, setMessages] = useState<string[]>([]);

  useEffect(() => {
    socket.on('chat message', (msg: string) => {
      setMessages((prev) => [...prev, msg]);
    });
    return () => { socket.off('chat message'); };
  }, []);

  return (
    <View style={styles.container}>
      {!isLoggedIn ? (
        <View>
          <Text style={styles.label}>Login</Text>
          <TextInput placeholder="Username" style={styles.input} value={username} onChangeText={setUsername} />
          <TextInput placeholder="Password" style={styles.input} value={password} onChangeText={setPassword} secureTextEntry />
          <Button title="Login" onPress={() => setIsLoggedIn(true)} />
        </View>
      ) : (
        <View>
          <Text style={styles.label}>Welcome, {username}!</Text>
          <FlatList
            data={messages}
            keyExtractor={(_, i) => i.toString()}
            renderItem={({ item }) => <Text>{item}</Text>}
            style={styles.chat}
          />
          <TextInput value={chatInput} onChangeText={setChatInput} placeholder="Type a message" style={styles.input} />
          <Button title="Send" onPress={() => {
            if (chatInput.trim() !== '') {
              socket.emit('chat message', `${username}: ${chatInput}`);
              setChatInput('');
            }
          }}/>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', padding: 30 },
  label: { fontSize: 22, marginBottom: 18 },
  input: { backgroundColor: '#eee', padding: 10, marginBottom: 10, borderRadius: 5 },
  chat: { minHeight: 100, maxHeight: 200, marginBottom: 10 },
});
