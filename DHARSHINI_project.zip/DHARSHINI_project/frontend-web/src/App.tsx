import React, { useState } from "react";
import axios from "axios";
import {
  Container, Box, TextField, Button, Typography, Snackbar, Tabs, Tab, Paper, Avatar,
} from "@mui/material";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";

const API = 'http://localhost:5000';

function TabPanel({children, value, index}: any) {
  return value === index ? <Box sx={{p:3}}>{children}</Box>: null;
}

export default function App() {
  const [tab, setTab] = useState(0);
  const [fields, setFields] = useState({email:'', password:'', name:'', role:'student'});
  const [token, setToken] = useState<string|null>(null);
  const [profile, setProfile] = useState<any>(null);
  const [snack, setSnack] = useState<string>('');
  const [profileDraft, setProfileDraft] = useState<any>({});

  // AUTH
  const handleLogin = async (e: any) => {
    e.preventDefault();
    try {
      const res = await axios.post(`${API}/auth/login`, { email: fields.email, password: fields.password });
      setToken(res.data.token);
      setSnack('Login successful!');
      setTab(2);
    } catch (err: any) {
      setSnack(err.response?.data?.error || 'Login failed');
    }
  };
  const handleRegister = async (e: any) => {
    e.preventDefault();
    try {
      await axios.post(`${API}/auth/register`, 
        { name: fields.name, email: fields.email, password: fields.password, role: fields.role });
      setSnack('Registration success. Please log in.');
      setTab(0);
    } catch (err: any) {
      setSnack(err.response?.data?.error || 'Registration failed');
    }
  };

  // PROFILE
  const loadProfile = async () => {
    try {
      const {data} = await axios.get(`${API}/profile`, { headers: { Authorization: `Bearer ${token}` } });
      setProfile(data); setProfileDraft(data||{});
    } catch {
      setSnack('Profile not found. Create one!');
      setProfileDraft({ skills:'', interests:'', hackathonExp:'' });
    }
  };
  const saveProfile = async (e: any) => {
    e.preventDefault();
    try {
      await axios.post(`${API}/profile`, profileDraft, { headers: { Authorization: `Bearer ${token}` } });
      setSnack('Profile updated');
      loadProfile();
    } catch {
      setSnack('Profile update failed');
    }
  };

  // UI PAGES
  if (!token) {
    return (
      <Container maxWidth="xs" sx={{mt:12}}>
        <Paper elevation={4} sx={{p:3, py:5, textAlign:'center'}}>
          <Avatar sx={{m:'auto', bgcolor:'primary.main'}}><LockOutlinedIcon /></Avatar>
          <Tabs value={tab} onChange={(_,v)=>setTab(v)} sx={{mb:2}}>
            <Tab label="Login" />
            <Tab label="Register" />
          </Tabs>
          <TabPanel value={tab} index={0}>
            <form onSubmit={handleLogin}>
              <TextField fullWidth margin="normal" label="Email" type="email"
                value={fields.email} required
                onChange={e=>setFields({...fields, email:e.target.value})}/>
              <TextField fullWidth margin="normal" label="Password" type="password"
                value={fields.password} required
                onChange={e=>setFields({...fields, password:e.target.value})}/>
              <Button fullWidth type="submit" sx={{mt:2}} variant="contained">Sign In</Button>
            </form>
          </TabPanel>
          <TabPanel value={tab} index={1}>
            <form onSubmit={handleRegister}>
              <TextField fullWidth label="Name" margin="normal"
                value={fields.name} required
                onChange={e=>setFields({...fields, name:e.target.value})}/>
              <TextField fullWidth label="Email" margin="normal"
                value={fields.email} required type="email"
                onChange={e=>setFields({...fields, email:e.target.value})}/>
              <TextField fullWidth label="Password" type="password" margin="normal"
                value={fields.password} required
                onChange={e=>setFields({...fields, password:e.target.value})}/>
              <TextField fullWidth select margin="normal" SelectProps={{native:true}}
                value={fields.role} onChange={e=>setFields({...fields, role:e.target.value})}
                label="Role">
                <option value="student">Student</option>
                <option value="recruiter">Recruiter</option>
                <option value="expert">Expert</option>
              </TextField>
              <Button fullWidth type="submit" sx={{mt:2}} variant="contained">Register</Button>
            </form>
          </TabPanel>
        </Paper>
        <Snackbar open={!!snack} autoHideDuration={2500} onClose={()=>setSnack('')} message={snack}/>
      </Container>
    );
  }

  // PROFILE PAGE
  return (
    <Container maxWidth="sm" sx={{pt:8}}>
      <Paper elevation={3} sx={{p:4}}>
        <Box display="flex" justifyContent="space-between" alignItems="center">
          <Typography variant="h5">Profile</Typography>
          <Button onClick={() => { setToken(null); setProfile(null); setTab(0); }} color="secondary">Log out</Button>
        </Box>
        <form onSubmit={saveProfile} style={{marginTop: 24}}>
          <TextField fullWidth label="Skills (comma separated)" name="skills"
            value={profileDraft.skills || ''} margin="normal"
            onChange={e=>setProfileDraft({...profileDraft, skills:e.target.value})}/>
          <TextField fullWidth label="Interests" name="interests"
            value={profileDraft.interests || ''} margin="normal"
            onChange={e=>setProfileDraft({...profileDraft, interests:e.target.value})}/>
          <TextField fullWidth label="Hackathon Experience" name="hackathonExp"
            value={profileDraft.hackathonExp || ''} margin="normal"
            onChange={e=>setProfileDraft({...profileDraft, hackathonExp:e.target.value})}/>
          <Button variant="contained" type="submit" sx={{mt:2}}>Save Profile</Button>
          <Button sx={{ml:2, mt:2}} onClick={loadProfile} variant="outlined">Reload</Button>
        </form>
        <Snackbar open={!!snack} autoHideDuration={2500} onClose={()=>setSnack('')} message={snack}/>
      </Paper>
    </Container>
  );
}
